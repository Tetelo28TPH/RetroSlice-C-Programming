﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static MILESTONE_1_PRG_PROJECT.Program;

namespace MILESTONE_1_PRG_PROJECT
{
    //begining of new class program
    public class Applicant
    {
        public String Name;
        public int userAge;
        public int ScoreRank;
        public DateTime startdate;
        public int pizzaseaten;
        public int bowlingScore;
        public String EmployeeStatus;
        public String SlushFlavour;
        public int slushiesConsumed;
        public string Allergy;
    }
    public class ApplicantsCollection
    {
        private List<Applicant> Applicants = new List<Applicant>();

        public void AddApplicant(String name, int age, int SRank, DateTime SDate, int PizzaEaten, int BowlingScore, String Status, String slushflavour, int Slushconsumed,string Type)
        {
            Applicant applicant = new Applicant
            {
                Name = name,
                userAge = age,
                ScoreRank = SRank,
                startdate = SDate,
                pizzaseaten = PizzaEaten,
                bowlingScore = BowlingScore,
                EmployeeStatus = Status,
                SlushFlavour = slushflavour,
                slushiesConsumed = Slushconsumed,
                Allergy  = Type,
            };
            Applicants.Add(applicant);
        }

        public List<Applicant> GetApplicants()
        {
            return Applicants;
        }
        public void GetAge(List<Applicant> applicants)
        {
            for (int i = 0; i < applicants.Count; i++)
            {
                for (int j = 0; j < applicants.Count - 1; j++)
                {
                    if (applicants[j].userAge > applicants[j + 1].userAge)
                    {
                        Applicant temp = applicants[j];
                        applicants[j] = applicants[j + 1];
                        applicants[j + 1] = temp;
                    }
                }
            }


        }

       


    }

    internal class Program

    {


        enum Menu
        {
            Capture_details = 1,
            Check_game_token_credit_qualificaton,
            Show_current_accade_and_bowling_stats,
            Pizza_average,
            Pizza_offers,
           Exit_Program

        }
        enum Capturedetails
        {
            Capture_Applicant_details=1,
            Get_age,
            Display_Applicant,
           
            Exit
        }

        



        //Menu application for Capture Details

        public static void menuDetails ()
        {

            Console.WriteLine("Please make a choice");
            Console.WriteLine("______________________________________________________");
            Console.WriteLine("Press 1 for Capture applicant details");
            Console.WriteLine("Press 2 to Get ages");
            Console.WriteLine("Press 3 to Display Applicants");
            Console.WriteLine("______________________________________________________");
            Console.WriteLine("Choose an option");
            int choice = int.Parse(Console.ReadLine());

            Capturedetails subMain = (Capturedetails)choice;


            while (true)
            {
                switch (subMain)
                {
                    case Capturedetails.Capture_Applicant_details:
                        Capture_details();
                        break;
                    case Capturedetails.Get_age:
                        Age();
                        break;
                    case Capturedetails.Display_Applicant:
                        Display();
                        break;
                    case Capturedetails.Exit:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Option is not available");
                        break;
                }

            }


        }
        public static void Capture_details()
        {
            //To retrieve the details from the applicants
            //store the details in the collection
            //display the applicants


            ApplicantsCollection applicantsCollection = new ApplicantsCollection();

            bool Continue = true;
            while (Continue)
            {
                Console.Clear();
                Console.WriteLine("Please enter your name");
                String name = Console.ReadLine();
                Console.WriteLine("Please enter your age");
                int age = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Please enter your score rank");
                int srank = Convert.ToInt32(Console.ReadLine());
                DateTime sdate = DateTime.Now;
                Console.WriteLine("How many pizza's have you eaten");
                int pizza = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("What's your bowling score");
                int score = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("What is your employment status");
                String status = Console.ReadLine();
                Console.WriteLine("What is your favourite slush flavour");
                String flavour = Console.ReadLine();
                Console.WriteLine("How many slushies have you consumed");
                int slushiesconsumed = Convert.ToInt32(Console.ReadLine());
                //New added feature that checks if customer has allegies
                Console.WriteLine("Do you have any allergies, and if yes, what are you  allergic to");
                string Type = Console.ReadLine();





                applicantsCollection.AddApplicant(name, age, srank, sdate, pizza, score, status, flavour, slushiesconsumed,Type);

                Console.WriteLine("Do you want to capture another applicant, Y/N");
                String Response = Console.ReadLine();

                if (Response == "N")
                {
                    Continue = false;
                    break;
                }
            }
 
            
           


        }

        //Method to display applicants

        static void Display()
        {

            ApplicantsCollection applicantsCollection = new ApplicantsCollection();
            //Display information
            List<Applicant> applicants = applicantsCollection.GetApplicants();
            foreach (Applicant applicant in applicants)
            {
                Console.WriteLine($"Name: {applicant.Name}, Age: {applicant.userAge}, Score Rank: {applicant.ScoreRank}, Starting date: {applicant.startdate}, Pizza's Eaten: {applicant.pizzaseaten}, Bowling Score: {applicant.bowlingScore}, Employee Status: {applicant.EmployeeStatus}, Slush Flavour: {applicant.SlushFlavour}, Slushies Consumed: {applicant.slushiesConsumed}");
            }

        }

        //Method that retrieves the lowest and highest age of applicants
        static void Age()
        {
            ApplicantsCollection applicantsCollection = new ApplicantsCollection();
            List<Applicant> applicants = applicantsCollection.GetApplicants();


            Applicant youngest = applicants[0];
            Applicant oldest = applicants[applicants.Count - 1];
            applicantsCollection.GetAge(applicants);
            Console.WriteLine("Youngest Applicant: " + youngest.userAge);
            Console.WriteLine("Oldest Applicant: " + oldest.userAge);
        }


        // Method to determine if applicant  qualify for credit or not.
        public static void Check_game_token_credit_qualificaton()
        { 
            string Userinput;
            int Age = 18;
            string ParentsEmployed = "";
            string Employed = "yes";

            while (true)
            {
                Console.WriteLine("Please specify your age");
                Age = int.Parse(Console.ReadLine());
                if (Age < 18)
                {
                    Console.WriteLine("Are your parents employed");
                    ParentsEmployed = Console.ReadLine();
                    break;
                }
               if(Age >= 18)
                {
                    Console.WriteLine("Are you employed, answer Yes/No");
                    Employed = Console.ReadLine();
                }
                
            if (ParentsEmployed == "No")
                {
                    Console.WriteLine("You do not Qualify");


                }

                if (ParentsEmployed == "Yes")
                {
                    Console.WriteLine("1/4, conditions checked");

                }



                if (Age > 18 && Employed == "No")
                {
                    Console.WriteLine("You do not Qualify");

                }

              if (Age > 18 && Employed == "Yes")
                {
                    Console.WriteLine("One condition checked, please wait for further processing.");
                }

                Console.WriteLine("How many years  have you  been a customer of RetroSlice");
                int YearLoyal = int.Parse(Console.ReadLine());
                if (YearLoyal < 2)
                {
                    Console.WriteLine("Sorry, you do not qualify. You have to atleast be a loyal customer for two years");
                }
                if (YearLoyal>  2) 
                {
                    Console.WriteLine("Condition checked");


                }

                Console.WriteLine("please enter number of pizzas eaten since first visit");
                int Pizzaseaten;
                Pizzaseaten = int.Parse(Console.ReadLine());
                if (Pizzaseaten >= 3)
                {
                    Console.WriteLine("Condition checked");
                    break;

                }
                if (Pizzaseaten < 3)
                {
                    Console.WriteLine("Sorry but you do not qualify");
                    break;
                }

                Console.WriteLine("Please enter your combined average");
                int Average;
                Average = int.Parse(Console.ReadLine());
                if (Average > 1200)
                {
                    Console.WriteLine("Condition checked");
                    break;
                }
                if (Average < 1200)
                {
                    Console.WriteLine("Sorry, but you do not qualify");
                    break;
                }


                Console.WriteLine("please enter the number of slushies consumed since first visit");
                int SlushiesDrank = int.Parse(Console.ReadLine());
                Console.WriteLine("What is your favourite slush flavour   ");
                string preference = " ";

                if (preference == "Gooey_Gulp_Galore")
                {
                    Console.WriteLine("Congratulations. You Have qualified");
                }
                if (preference != "Gooey_Gulp_Galore")
                {
                    Console.WriteLine("Sorry but you don't qualify");
                }

            }

          
            Console.WriteLine("Do you want to capture another applicant");
            String Response = Console.ReadLine().ToUpper();

            while (true)
            {
                if (Response == "N")
                {
                    break;
                }
            }

        }

        //Method to display applicant'accade and bowling
        public static void Show_current_accade_and_bowling_stats()
        {

            int bowlHighScore = 0;
            int arcadeHighScore = 0;
            ApplicantsCollection applicantsCollection = new ApplicantsCollection();
            List<Applicant> applicants = applicantsCollection.GetApplicants();

            foreach (Applicant applicant in applicants)
            {
                if (applicant.bowlingScore > arcadeHighScore)
                {
                    bowlHighScore = applicant.bowlingScore;
                }

                if (applicant.ScoreRank > arcadeHighScore)
                {
                    arcadeHighScore = applicant.ScoreRank;
                }
            }

            Console.WriteLine("Bowling Score: " + bowlHighScore);
            Console.WriteLine("Arcade Score: " + arcadeHighScore);


        }//end of accade and bowling stats method



        static void loadingEfects()
        {
            
            for (int i = 0; i < 11; i++)
            {
                Console.WriteLine($"Processing({i*10})%");
                Thread.Sleep(900);
                Console.Clear();
               

            }

        }

        static void Anime()
        {
            string text = "Welcome to RetroSlice";

            for (int i = 0; i < text.Length; i++)
            {
                Console.Write(text[i]);
                Thread.Sleep(400);
               
            }
        }//end of animation method

        private static bool CursorVisible;

        //Method to calculate the average number of pizzas consumed per first visit.
        static void PizzaAverage()
        {
            List<Applicant> Applicants = new List<Applicant>();

            Applicant applicant = new Applicant();


            double avg = 0.00;
            for (int i = 0; i < Applicants.Count; i++)
            {
                avg += applicant.pizzaseaten;
            }

            avg = avg / Applicants.Count;
            Console.WriteLine("The average is : " + avg);

        }
        static void PizzaOffers() //Loyal customers who have eaten 100 or more pizzas will receive a discount on their meals
        {
            Applicant applicant = new Applicant();

            if (applicant.pizzaseaten >= 100)
            {
                Console.WriteLine("The customer does qualifiy for a discounts");
            }
            else
            {
                Console.WriteLine("The customer does not qualify for a discount");
            }


        }
        //How to check if an applicant qualifies for a long-term loyalty award
        static void LongTermReward()
        {
            List<Applicant> Applicants = new List<Applicant>();

            Applicant applicant = new Applicant();

            foreach (var reward in Applicants)
            {
                foreach (Applicant reward1 in Applicants)
                {
                    if ((DateTime.Now - applicant.startdate).TotalDays >= 365 * 10)
                    {
                        continue;
                    }
                }

               
            }
            Console.WriteLine($"{applicant.Name} qualifies for an unlimited number of credits");
        }

        static void Main(string[] args)

        {
            int choice;
            bool entrance = true;
            List<Applicant> applicants;

            Anime();
           Console.Clear();
            Console.WriteLine("Please choose an option");
            Console.WriteLine("______________________________________________________");
            Console.WriteLine("Option 1: Capture details subMenu");
            Console.WriteLine("Option 2: Check game token credit qualification");
            Console.WriteLine("Option 3: Show current accade and bowling stats");
            Console.WriteLine("Option 4: Pizza average");
            Console.WriteLine("Option 5: Pizza offers");
            Console.WriteLine("Option 6: Exit");
            Console.WriteLine("______________________________________________________");
            choice = int.Parse(Console.ReadLine());

            Menu main = (Menu)choice;

            while (entrance == true)
            {


                switch (main)
                {
                    case Menu.Capture_details:
                        CursorVisible = false;
                        loadingEfects();
                        CursorVisible = true;
                        menuDetails();
                        break;
                    case Menu.Check_game_token_credit_qualificaton:
                        CursorVisible = false;
                        loadingEfects();
                        CursorVisible = true;
                        Check_game_token_credit_qualificaton();
                        break;
                    case Menu.Show_current_accade_and_bowling_stats:
                        CursorVisible = false;
                        loadingEfects();
                        CursorVisible = true;
                        Show_current_accade_and_bowling_stats();
                        break;
                    case Menu.Pizza_average:
                        CursorVisible = false;
                        loadingEfects();
                        CursorVisible = true;
                        break;
                    case Menu.Pizza_offers:
                        CursorVisible = false;
                        loadingEfects();
                        CursorVisible = true;
                        PizzaOffers();
                        break;
                   
                        
                    case Menu.Exit_Program:
                        Environment.Exit(0);
                        break;
                    default:
                        break;
                }
            }



            Console.ReadLine();



        } }
    }
